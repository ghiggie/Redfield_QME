This program will simulate the Redfield master equation for a single qubit coupled to a single bath. It is expected that this equation does not preserve positivity of the density operator.
